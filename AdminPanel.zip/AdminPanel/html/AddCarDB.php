<?php

$car_mod=$_POST['carmodel'];
$car_type=$_POST['cartype'];
$car_brand=$_POST['carbrand'];
$car_price=$_POST['carprice'];
$rURL=$_POST['rev_url'];
$iURL=$_POST['img_url'];


$con=mysqli_connect('localhost','root','','carhunt');
if(!$con)
	{
		echo "connection failed";
		die();
	}
	elseif((!empty($car_mod))&&(!empty($car_type))&&(!empty($car_brand))&&(!empty($car_price))&&(!empty($rURL))&&(!empty($iURL)))
	{
	  mysqli_select_db($con,"car");
      $query1="INSERT INTO car  (carid,type,brand,price,review_url,image_url) VALUES ('$car_mod','$car_type','$car_brand','$car_price','$rURL','$iURL')";
      if(mysqli_query($con,$query1))
      { 
      	session_start();
      	$_SESSION['msg']='Insertion Successfull';
        header('Location:AddCarpage.php');
        mysqli_close($con);
      } 
      else
      {
       header("Refresh:0;url:AddCarpage.php");
      echo '<script type="text/javascript">alert("Insertion Failed!!");window.history.go(-1);</script>'; 
      }
	}
	else
    {
        header("Refresh:0;url:AddCarpage.php");
        echo '<script type="text/javascript">alert("Fields cannot be empty");window.history.go(-1);</script>';

    }
    
?>